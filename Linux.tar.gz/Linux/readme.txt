Linux setup and configuration

1.PDF file
2.HTML file
3.MD file 

Choose one you like