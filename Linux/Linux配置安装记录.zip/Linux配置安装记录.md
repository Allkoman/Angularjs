# Linux配置安装记录
@(工作记录)[环境搭建, 优化美化, 常见错误, 软件推荐, ]

**原因**：2016-7-29日 星期五 由于机器声卡出现问题，耳机无法使用， 始终是外放，无法观看教学视频，决定修改驱动参数，于是：系统无限重启决定重新配置环境并记录
**说明**：由于工作需要，接触需要使用Linux开发环境，与之前个人常用的Mac与Windows还是有较大区别，进行详细记录（其实是各种错误BUG重装了好几次后的笔记...）
**环境**:Ubuntu 16.04

-------------------
[TOC]

### 安装
> 首先使用的是U盘刻录后在Win10基础上的双系统，Win引导Linux，可以用 [Ultraiso](http://www.ezbsystems.com/ultraiso/)进行刻录安装U盘，开机选择启动项为U盘后安装，我为Ubuntu预留了100G空间。主逻辑分区/ 22000mb，swap交换空间2048mb，/boot 200mb，/home分配剩余的空间，启动器挂在于/boot所在的盘符，由win引导ubuntu用easybcd更改即可。

-------------------
### Passwd 
```
sudo passwd
```
>进入Ubuntu第一件事情，重置sudo密码，由于使用频繁，推荐简易的密码

-------------------
###Git&Solrized
```
sudo apt install git
git clone --recursive https://github.com/reversiblean/solarized-light-ubuntu.git
Run ./install.sh
```
![Alt text](1469778683792.png)
>有效保护眼睛的主题,个人喜好～

-------------------
###Unity Tweak Tool
```
sudo add-apt-repository ppa:freyja-dev/unity-tweak-tool-daily
sudo apt-get update
sudo apt-get install unity-tweak-tool
```
>可用于强迫症将左侧的边栏移动到下方并隐藏，便于增大屏幕利用率，使用锁定在边栏的软件可以通过WIN+1,2,3等数字的方式唤醒。
![Alt text](1469779202471.png)
>如下图，工作时完全可以从下方呼出菜单栏，Tweak还有分屏，workspace等很强大的功能
![Alt text](./Selection_003.png)


-------------------
###Unity Numix
```
sudo apt-add-repository ppa:numix/ppa
sudo apt-get update
sudo apt-get install numix-icon-theme-circle
```
>比较炫酷的icons主题

-------------------
###Shutter 
```
sudo add-apt-repository ppa:shutter/ppa
sudo apt-get update
sudo apt-get install shutter
```
>截图工具，可自定义快捷键，方便好用

-------------------
###Unity Arc
```
sudo sh -c "echo 'deb http://download.opensuse.org/repositories/home:/Horst3180/xUbuntu_16.04/ /' >> /etc/apt/sources.list.d/arc-theme.list"
sudo apt-get update
sudo apt-get install arc-theme
```
>比较炫酷的theme

-------------------
###Ubuntu Nvidia
```
sudo add-apt-repository ppa:graphics-drivers/ppa
sudo apt-get update
sudo apt-get install nvidia-364.
```
>nvidia系列笔记本必装驱动。（否则系统自带的带不动多显示器）

-------------------
###Gdebi（//）
```
sudo apt install gdebi
```
>安装完成后，将deb文件默认打开方式设为gdebi：右键点击deb文件，打开properties，选择open with，选中GDebi Package Installer. 并Set as default。
>//后验证不如dpkg直接安装好用，本条可忽略

-------------------
###JDK
>在官网下载JDK文件，安装并配置
>首先cd到下载好的压缩包的文件夹，创建一个jvm文件夹，并将其解压进去
```
sudo mkdir /usr/lib/jvm
sudo tar zxvf jdk-8u101-linux-x64.tar.gz -C /usr/lib/jvm
```
>打开bashrc文件，在底下加上四条参数
```
gedit ~/.bashrc
export JAVA_HOME=/usr/lib/jvm/jdk1.8.0_101  
export JRE_HOME=/usr/lib/jvm/jdk1.8.0_101/jre   
export CLASSPATH=.:$JAVA_HOME/lib:$JRE_HOME/lib:$CLASSPATH  
export PATH=$JAVA_HOME/bin:$JRE_HOME/bin:$JAVA_HOME:$PATH
```
>最后测试一下是否安装成功

![Alt text](1469782321030.png)

-------------------

###Node&Npm&Bower
```
sudo apt install nodejs-legacy
sudo apt install npm
sudo npm install -g bower
```

-------------------
